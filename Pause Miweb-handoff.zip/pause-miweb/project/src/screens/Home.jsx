function HomeScreen({ go, quote }) {
  const [mouse, setMouse] = React.useState({ x: 50, y: 50 });
  return (
    <div className="home">
      <div>
        <div className="logo home-logo">
          <span className="pause">Pause</span><span className="miweb">Miweb</span>
        </div>
        <div className="tagline" style={{ marginTop: 8 }}>Le quizz entre collègues</div>
      </div>
      <div className="home-quote">
        « {quote.text} »
        <cite>— {quote.author}</cite>
      </div>
      <div className="mode-grid">
        <div
          className="card mode-card"
          onMouseMove={e => {
            const r = e.currentTarget.getBoundingClientRect();
            e.currentTarget.style.setProperty('--mx', `${((e.clientX - r.left) / r.width) * 100}%`);
            e.currentTarget.style.setProperty('--my', `${((e.clientY - r.top) / r.height) * 100}%`);
          }}
          onClick={() => go('setup')}
        >
          <div className="shine" />
          <div className="icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="2" y="8" width="20" height="10" rx="5"/>
              <path d="M7 12h2M8 11v2"/>
              <circle cx="16" cy="13" r="1" fill="currentColor"/>
              <circle cx="18" cy="11" r="1" fill="currentColor"/>
            </svg>
          </div>
          <h3>Solo / Local</h3>
          <p>À tour de rôle sur le même écran</p>
        </div>
        <div
          className="card mode-card"
          onMouseMove={e => {
            const r = e.currentTarget.getBoundingClientRect();
            e.currentTarget.style.setProperty('--mx', `${((e.clientX - r.left) / r.width) * 100}%`);
            e.currentTarget.style.setProperty('--my', `${((e.clientY - r.top) / r.height) * 100}%`);
          }}
          onClick={() => go('setup')}
        >
          <div className="shine" />
          <div className="icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="9" cy="8" r="3"/>
              <circle cx="17" cy="9" r="2.2"/>
              <path d="M3 19a6 6 0 0 1 12 0"/>
              <path d="M15 18a5 5 0 0 1 6 0"/>
            </svg>
          </div>
          <h3>Multijoueur</h3>
          <p>Chacun sur son téléphone, party style</p>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { HomeScreen });
