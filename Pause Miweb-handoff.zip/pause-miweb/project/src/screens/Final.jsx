function FinalScreen({ scores, maxCombo, go }) {
  const sorted = [...scores].sort((a, b) => b.score - a.score);
  const podium = sorted.slice(0, 3);
  const [fwTrigger, setFwTrigger] = React.useState(0);

  React.useEffect(() => {
    setFwTrigger(t => t + 1);
    const iv = setInterval(() => setFwTrigger(t => t + 1), 3500);
    return () => clearInterval(iv);
  }, []);

  const totalQuestions = 20;
  const mvp = sorted[0];
  const accuracy = mvp ? Math.round((mvp.score / (totalQuestions * 2)) * 100) : 0;

  // Order for visual podium: 2nd, 1st, 3rd
  const layout = [podium[1], podium[0], podium[2]].filter(Boolean);

  return (
    <div className="final">
      <Fireworks trigger={fwTrigger} />
      <Confetti trigger={fwTrigger} count={60} />
      <div>
        <div className="final-title">Fin de la partie !</div>
        <div className="final-subtitle" style={{ textAlign: 'center', marginTop: 10 }}>
          Bravo <strong style={{ color: 'var(--gold)' }}>{mvp?.name}</strong>, tu étales la confiture comme personne.
        </div>
      </div>

      <div className="podium-stage">
        {layout.map((p, idx) => {
          const rank = p === podium[0] ? 1 : p === podium[1] ? 2 : 3;
          return (
            <div key={p.name} className="podium-pillar">
              {rank === 1 && <div style={{ position: 'relative' }}><div className="crown">👑</div></div>}
              <div className="podium-avatar" style={{
                background: p.color,
                boxShadow: rank === 1 ? '0 12px 30px rgba(251,191,36,0.5), 0 0 0 4px rgba(251,191,36,0.3)' : undefined,
              }}>
                {initials(p.name)}
              </div>
              <div className="name">{p.name}</div>
              <div className="score">{p.score} pts</div>
              <div className={`pillar-block pillar-${rank}`}>#{rank}</div>
            </div>
          );
        })}
      </div>

      <div className="final-stats">
        <div className="stat-card">
          <div className="val">×{maxCombo}</div>
          <div className="label">Combo max</div>
        </div>
        <div className="stat-card">
          <div className="val">{accuracy}%</div>
          <div className="label">Précision MVP</div>
        </div>
        <div className="stat-card">
          <div className="val">{totalQuestions}</div>
          <div className="label">Questions</div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 12 }}>
        <button className="btn-ghost" onClick={() => go('home')}>← Retour au menu</button>
        <button className="btn-primary" onClick={() => go('setup')}>Rejouer 🎲</button>
      </div>
    </div>
  );
}

Object.assign(window, { FinalScreen });
