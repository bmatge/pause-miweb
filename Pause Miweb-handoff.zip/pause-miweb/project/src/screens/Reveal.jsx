function RevealScreen({ go, lastAnswer, scores, prevScores, onNext, combo }) {
  const [clashPlayer, setClashPlayer] = React.useState(null);

  // Compute rank changes
  const prevRanks = React.useMemo(() => {
    const sorted = [...prevScores].sort((a, b) => b.score - a.score);
    const map = {};
    sorted.forEach((p, i) => { map[p.name] = i; });
    return map;
  }, [prevScores]);

  const sorted = [...scores].sort((a, b) => b.score - a.score);

  React.useEffect(() => {
    // Detect leader change for clash banner
    const newLeader = sorted[0]?.name;
    const oldLeader = [...prevScores].sort((a,b) => b.score - a.score)[0]?.name;
    if (newLeader && oldLeader && newLeader !== oldLeader) {
      setClashPlayer(newLeader);
      const t = setTimeout(() => setClashPlayer(null), 2500);
      return () => clearTimeout(t);
    }
  }, []);

  const correct = lastAnswer?.correct;
  const q = lastAnswer?.q;

  return (
    <div className="reveal">
      {correct ? (
        <div className="reveal-banner">
          <span>🎉</span>
          <span className="kicker">Bonne réponse :</span>
          <span className="ans">{q?.answers[q.correct]}</span>
        </div>
      ) : (
        <div className="reveal-banner" style={{
          background: 'rgba(255,56,96,0.12)',
          borderColor: 'rgba(255,56,96,0.35)',
        }}>
          <span>😬</span>
          <span className="kicker">La réponse était :</span>
          <span className="ans" style={{ color: 'var(--red)' }}>{q?.answers[q.correct]}</span>
        </div>
      )}

      {q?.fact && <div className="reveal-fact">« {q.fact} »</div>}

      {correct && combo >= 2 && (
        <div className="combo-flash">
          🔥 COMBO ×{combo} ! +{combo * 2} bonus
        </div>
      )}

      <div className="setup-section-title" style={{ marginTop: 8 }}>Classement</div>

      <div className="podium-list">
        {clashPlayer && <div className="clash-banner">⚡ CLASH ! {clashPlayer} PREND LA TÊTE</div>}
        {sorted.map((p, i) => {
          const prevRank = prevRanks[p.name];
          const diff = prevRank - i;
          let rowCls = 'podium-row';
          if (i === 0) rowCls += ' leader';
          if (diff > 0) rowCls += ' moving-up';
          else if (diff < 0) rowCls += ' moving-down';
          return (
            <div key={p.name} className={rowCls} style={{ transitionDelay: `${i * 0.08}s` }}>
              <div className="podium-rank">{i + 1}</div>
              <div className="podium-name">
                <div className="avatar" style={{ background: p.color, width: 32, height: 32, fontSize: 13 }}>
                  {initials(p.name)}
                </div>
                {p.name}
                {diff > 0 && <span className="podium-delta">▲ {diff}</span>}
                {diff === 0 && <span className="podium-delta zero">—</span>}
                {diff < 0 && <span className="podium-delta" style={{ background: 'rgba(255,56,96,0.2)', color: 'var(--red)' }}>▼ {Math.abs(diff)}</span>}
              </div>
              <div className="podium-score">{p.score} pts</div>
            </div>
          );
        })}
      </div>

      <div className="next-btn-wrap">
        <button className="btn-primary" style={{ minWidth: 320 }} onClick={onNext}>
          Question suivante →
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { RevealScreen });
