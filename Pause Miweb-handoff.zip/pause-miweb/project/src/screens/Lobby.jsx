function LobbyScreen({ go }) {
  const [players, setPlayers] = React.useState([]);
  React.useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      if (i >= PLAYER_POOL.length - 2) return clearInterval(timer);
      setPlayers(p => [...p, PLAYER_POOL[i]]);
      i++;
    }, 900);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="lobby">
      <div className="logo lobby-logo">
        <span className="pause">Pause</span><span className="miweb">Miweb</span>
      </div>
      <div className="qr-wrap">
        <QRBlock seed="PGF5" />
      </div>
      <div style={{ textAlign: 'center' }}>
        <div className="room-code">
          <span className="label">Code :</span>
          <span className="code">PGF5</span>
        </div>
        <div className="room-url">pause-miweb.matge.com/player?room=PGF5</div>
      </div>

      <div className="players-header">
        <div className="players-count">
          Joueurs connectés <span className="num">{players.length}</span>
        </div>
        {players.length > 0 && (
          <div style={{ color: 'var(--ink-3)', fontSize: 13, fontFamily: 'JetBrains Mono' }}>
            ça pop ! 🎉
          </div>
        )}
      </div>

      <div className="players-strip">
        {players.map((p, i) => (
          <div key={p.name} className="player-pill" style={{ animationDelay: `${i * 0.05}s` }}>
            <div className="avatar" style={{ background: p.color }}>
              {initials(p.name)}
            </div>
            {p.name}
          </div>
        ))}
        {players.length === 0 && (
          <div style={{ color: 'var(--ink-4)', fontStyle: 'italic', fontSize: 14, padding: '8px 0' }}>
            En attente de joueurs...
          </div>
        )}
      </div>

      <button
        className="btn-primary lobby-start"
        disabled={players.length < 2}
        onClick={() => go('question')}
      >
        {players.length < 2 ? 'En attente de joueurs...' : `Lancer la partie (${players.length}) →`}
      </button>
    </div>
  );
}

Object.assign(window, { LobbyScreen });
