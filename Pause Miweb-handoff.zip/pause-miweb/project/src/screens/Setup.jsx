function SetupScreen({ go }) {
  const [selected, setSelected] = React.useState(['cassetete', 'fake', 'geek']);
  const [count, setCount] = React.useState(20);
  const toggle = (id) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  return (
    <div className="setup">
      <div className="logo setup-logo">
        <span className="pause">Pause</span><span className="miweb">Miweb</span>
      </div>
      <div className="setup-subtitle">Le quizz entre collègues</div>
      <div className="setup-tag">
        C'est pas parce que je t'aime bien que je vais te laisser gagner.
        <strong>— Signé : tout le monde.</strong>
      </div>

      <div className="setup-section-title">Catégories</div>
      <div className="cat-grid">
        {CATEGORIES.map(c => (
          <div
            key={c.id}
            className={`chip ${selected.includes(c.id) ? 'active' : ''}`}
            onClick={() => toggle(c.id)}
          >
            <span className="dot" style={{ color: c.color }}>{c.icon}</span>
            {c.label}
          </div>
        ))}
      </div>

      <div className="setup-section-title">Nombre de questions</div>
      <div className="count-grid">
        {[10, 20, 30, 50].map(n => (
          <button
            key={n}
            className={`count-btn ${count === n ? 'active' : ''}`}
            onClick={() => setCount(n)}
          >{n}</button>
        ))}
      </div>

      <button className="btn-primary" style={{ width: '100%' }} onClick={() => go('lobby')}>
        Créer la partie ✨
      </button>
    </div>
  );
}

Object.assign(window, { SetupScreen });
