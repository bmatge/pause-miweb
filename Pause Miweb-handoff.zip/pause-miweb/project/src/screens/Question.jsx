function QuestionScreen({ go, qIndex, combo, onAnswer, timeLimit }) {
  const q = QUESTIONS[qIndex % QUESTIONS.length];
  const cat = catById(q.cat);
  const [selected, setSelected] = React.useState(null);
  const [revealing, setRevealing] = React.useState(false);
  const [time, setTime] = React.useState(timeLimit);

  React.useEffect(() => {
    setSelected(null);
    setRevealing(false);
    setTime(timeLimit);
  }, [qIndex, timeLimit]);

  React.useEffect(() => {
    if (revealing) return;
    if (time <= 0) { handleClick(-1); return; }
    const t = setTimeout(() => setTime(time - 1), 1000);
    return () => clearTimeout(t);
  }, [time, revealing]);

  const handleClick = (i) => {
    if (revealing) return;
    setSelected(i);
    setRevealing(true);
    setTimeout(() => onAnswer(i === q.correct, i, q), 1400);
  };

  const ringR = 26;
  const ringCirc = 2 * Math.PI * ringR;
  const ringDashoffset = ringCirc * (1 - time / timeLimit);
  const timerState = time <= 3 ? 'danger' : time <= 6 ? 'warn' : '';
  const comboFill = Math.min(100, (combo / 5) * 100);
  const comboClass = combo >= 5 ? 'blaze' : combo >= 3 ? 'hot' : '';

  return (
    <div className="question-wrap">
      <div className="question-topbar">
        <div className="qnum">
          Question <strong>{qIndex + 1}</strong>/ 20
        </div>
        <div className="progress-bar">
          <div className="progress-bar-fill" style={{ width: `${((qIndex + 1) / 20) * 100}%` }} />
        </div>
        <div className={`combo-meter`} style={{ '--combo-fill': `${comboFill}%` }}>
          <span className="combo-label">Combo</span>
          <span className={`combo-value ${comboClass}`}>
            ×{combo}
            {combo >= 3 && <span className="flame">🔥</span>}
          </span>
        </div>
        <div className={`timer-ring ${timerState}`}>
          <svg viewBox="0 0 60 60">
            <circle className="track" cx="30" cy="30" r={ringR} />
            <circle className="fill" cx="30" cy="30" r={ringR}
              strokeDasharray={ringCirc}
              strokeDashoffset={ringDashoffset}
              strokeLinecap="round"
            />
          </svg>
          <div className="timer-num">{time}</div>
        </div>
      </div>

      <div className="question-card" key={qIndex}>
        <div className="category-badge">
          <span>{cat.icon}</span> {cat.label}
        </div>
        <div className="question-text">{q.text}</div>
      </div>

      <div className="answers-grid">
        {q.answers.map((a, i) => {
          const letters = ['A', 'B', 'C', 'D'];
          let cls = 'answer-btn';
          if (revealing) {
            if (i === q.correct) cls += ' correct';
            else if (i === selected) cls += ' wrong';
            else cls += ' dimmed';
          } else if (selected === i) cls += ' selected';
          return (
            <button key={i} className={cls} onClick={() => handleClick(i)}>
              <span className="letter">{letters[i]}</span>
              <span className="label">{a}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { QuestionScreen });
