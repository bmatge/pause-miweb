const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "fxIntensity": "medium",
  "timePerQuestion": 15,
  "showParticles": true,
  "sound": false
}/*EDITMODE-END*/;

function TweaksPanel({ tweaks, setTweaks, visible }) {
  if (!visible) return null;
  const set = (k, v) => setTweaks({ ...tweaks, [k]: v });
  return (
    <div className="tweaks">
      <h4>🎛 Tweaks <span style={{ color: 'var(--ink-4)', fontWeight: 400 }}>v1</span></h4>
      <div className="row">
        <label>Intensité FX</label>
        <select value={tweaks.fxIntensity} onChange={e => set('fxIntensity', e.target.value)}>
          <option value="low">chill</option>
          <option value="medium">medium</option>
          <option value="high">bananas</option>
        </select>
      </div>
      <div className="row">
        <label>Temps / question</label>
        <input type="range" min="5" max="30" step="1"
          value={tweaks.timePerQuestion}
          onChange={e => set('timePerQuestion', +e.target.value)}
          style={{ width: 90 }}
        />
        <span style={{ color: 'var(--violet-2)', fontFamily: 'JetBrains Mono', fontSize: 12 }}>
          {tweaks.timePerQuestion}s
        </span>
      </div>
      <div className="row">
        <label>Particules ambiance</label>
        <button
          className={`tweaks-toggle ${tweaks.showParticles ? 'on' : ''}`}
          onClick={() => set('showParticles', !tweaks.showParticles)}
        >{tweaks.showParticles ? 'ON' : 'OFF'}</button>
      </div>
      <div className="row">
        <label>Sons (mock)</label>
        <button
          className={`tweaks-toggle ${tweaks.sound ? 'on' : ''}`}
          onClick={() => set('sound', !tweaks.sound)}
        >{tweaks.sound ? 'ON' : 'OFF'}</button>
      </div>
    </div>
  );
}

Object.assign(window, { TweaksPanel, TWEAK_DEFAULTS });
