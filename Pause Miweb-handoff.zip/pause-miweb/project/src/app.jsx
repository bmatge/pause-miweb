const { useState, useEffect, useMemo } = React;

const SCREENS = [
  { id: 'home', label: 'Home' },
  { id: 'setup', label: 'Setup' },
  { id: 'lobby', label: 'Lobby' },
  { id: 'question', label: 'Question' },
  { id: 'reveal', label: 'Reveal' },
  { id: 'final', label: 'Final' },
];

// Seed scores evolving over time for the podium demo
const INITIAL_SCORES = PLAYER_POOL.slice(0, 6).map(p => ({ ...p, score: 0 }));

function App() {
  const saved = (() => {
    try { return JSON.parse(localStorage.getItem('pm-state') || '{}'); } catch { return {}; }
  })();
  const [screen, setScreen] = useState(saved.screen || 'home');
  const [qIndex, setQIndex] = useState(saved.qIndex ?? 0);
  const [combo, setCombo] = useState(saved.combo ?? 0);
  const [maxCombo, setMaxCombo] = useState(saved.maxCombo ?? 0);
  const [scores, setScores] = useState(saved.scores || INITIAL_SCORES);
  const [prevScores, setPrevScores] = useState(saved.scores || INITIAL_SCORES);
  const [lastAnswer, setLastAnswer] = useState(null);
  const [confettiTrigger, setConfettiTrigger] = useState(0);
  const [streakMsg, setStreakMsg] = useState(null);
  const [tweakVisible, setTweakVisible] = useState(false);
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);

  const quote = useMemo(() => QUOTES[Math.floor(Math.random() * QUOTES.length)], []);

  useEffect(() => {
    localStorage.setItem('pm-state', JSON.stringify({ screen, qIndex, combo, maxCombo, scores }));
  }, [screen, qIndex, combo, maxCombo, scores]);

  // Edit mode protocol
  useEffect(() => {
    const onMsg = (e) => {
      if (e.data?.type === '__activate_edit_mode') setTweakVisible(true);
      if (e.data?.type === '__deactivate_edit_mode') setTweakVisible(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  useEffect(() => {
    if (JSON.stringify(tweaks) !== JSON.stringify(TWEAK_DEFAULTS)) {
      window.parent.postMessage({ type: '__edit_mode_set_keys', edits: tweaks }, '*');
    }
  }, [tweaks]);

  const go = (s) => {
    setScreen(s);
    if (s === 'home' || s === 'setup') {
      setQIndex(0);
      setCombo(0);
      setMaxCombo(0);
      setScores(INITIAL_SCORES);
      setPrevScores(INITIAL_SCORES);
    }
  };

  const handleAnswer = (correct, chosen, q) => {
    setLastAnswer({ correct, chosen, q });
    setPrevScores(scores);

    // Update scores - our player (Bertrand) + simulated bots
    const newScores = scores.map((p, i) => {
      if (i === 0) {
        // Our player
        if (correct) {
          const bonus = combo >= 2 ? combo * 2 : 0;
          return { ...p, score: p.score + 2 + bonus };
        }
        return p;
      }
      // Bots: random success
      const gotIt = Math.random() > 0.4;
      return { ...p, score: p.score + (gotIt ? 2 : 0) };
    });
    setScores(newScores);

    if (correct) {
      setConfettiTrigger(t => t + 1);
      const newCombo = combo + 1;
      setCombo(newCombo);
      setMaxCombo(Math.max(maxCombo, newCombo));
      if (newCombo >= 3) {
        setStreakMsg(`🔥 STREAK ×${newCombo}`);
        setTimeout(() => setStreakMsg(null), 2000);
      }
    } else {
      setCombo(0);
    }
    setScreen('reveal');
  };

  const handleNext = () => {
    if (qIndex + 1 >= 20) {
      setScreen('final');
    } else {
      setQIndex(qIndex + 1);
      setScreen('question');
    }
  };

  const particleCount = tweaks.fxIntensity === 'high' ? 50 : tweaks.fxIntensity === 'low' ? 12 : 30;

  return (
    <div className="app-shell">
      {tweaks.showParticles && <AmbientDots count={particleCount} />}
      <BgIcons />

      <div className="screen-nav">
        {SCREENS.map(s => (
          <button
            key={s.id}
            className={screen === s.id ? 'active' : ''}
            onClick={() => {
              if (s.id === 'question' && qIndex >= 20) setQIndex(0);
              setScreen(s.id);
            }}
          >{s.label}</button>
        ))}
      </div>

      <div className="screen-stage">
        {screen === 'home' && <HomeScreen go={go} quote={quote} />}
        {screen === 'setup' && <SetupScreen go={go} />}
        {screen === 'lobby' && <LobbyScreen go={go} />}
        {screen === 'question' && (
          <QuestionScreen
            qIndex={qIndex}
            combo={combo}
            onAnswer={handleAnswer}
            timeLimit={tweaks.timePerQuestion}
          />
        )}
        {screen === 'reveal' && (
          <RevealScreen
            lastAnswer={lastAnswer}
            scores={scores}
            prevScores={prevScores}
            onNext={handleNext}
            combo={combo}
          />
        )}
        {screen === 'final' && <FinalScreen scores={scores} maxCombo={maxCombo} go={go} />}
      </div>

      {streakMsg && <div className="streak-badge">{streakMsg}</div>}
      <Confetti trigger={confettiTrigger} count={tweaks.fxIntensity === 'high' ? 120 : 60} />

      <TweaksPanel tweaks={tweaks} setTweaks={setTweaks} visible={tweakVisible} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
