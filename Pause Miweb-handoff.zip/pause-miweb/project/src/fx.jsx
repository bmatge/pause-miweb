// Visual FX components: confetti, fireworks, particles, ambient dots

function AmbientDots({ count = 30 }) {
  const dots = React.useMemo(() => Array.from({ length: count }, (_, i) => ({
    left: Math.random() * 100,
    delay: Math.random() * 14,
    dur: 10 + Math.random() * 8,
    size: 2 + Math.random() * 3,
  })), [count]);
  return (
    <div className="ambient-dots">
      {dots.map((d, i) => (
        <span key={i} style={{
          left: `${d.left}%`,
          bottom: '-10px',
          width: d.size, height: d.size,
          animationDelay: `-${d.delay}s`,
          animationDuration: `${d.dur}s`,
        }} />
      ))}
    </div>
  );
}

function BgIcons() {
  return (
    <>
      <div className="bg-icon" style={{ top: '8%', left: '4%', width: 140, height: 140 }}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4"><circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"/><circle cx="12" cy="17" r=".6" fill="currentColor"/></svg>
      </div>
      <div className="bg-icon" style={{ bottom: '10%', right: '6%', width: 120, height: 120 }}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4"><path d="M7 4h10l-1 5h3l-5 11 1-7H11l2-9"/></svg>
      </div>
      <div className="bg-icon" style={{ top: '55%', left: '8%', width: 110, height: 110 }}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4"><path d="M6 9h12l-1 7a3 3 0 0 1-3 3h-4a3 3 0 0 1-3-3z"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/><path d="M4 10h2M18 10h2"/></svg>
      </div>
      <div className="bg-icon" style={{ top: '20%', right: '10%', width: 130, height: 130 }}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4"><path d="M12 3l2.5 5 5.5.8-4 3.9 1 5.5L12 15.8 7 18.2l1-5.5-4-3.9 5.5-.8z"/></svg>
      </div>
    </>
  );
}

function Confetti({ count = 80, trigger = 0 }) {
  const [pieces, setPieces] = React.useState([]);
  React.useEffect(() => {
    if (!trigger) return;
    const colors = ['#7c5cff', '#22d3ee', '#10e0a0', '#fbbf24', '#ff4d8d', '#ff6d3d'];
    const p = Array.from({ length: count }, (_, i) => ({
      id: `${trigger}-${i}`,
      left: Math.random() * 100,
      delay: Math.random() * 0.5,
      dur: 2.5 + Math.random() * 2,
      rot: Math.random() * 360,
      bg: colors[Math.floor(Math.random() * colors.length)],
      shape: Math.random() > 0.5 ? '4px' : '50%',
    }));
    setPieces(p);
    const t = setTimeout(() => setPieces([]), 5000);
    return () => clearTimeout(t);
  }, [trigger, count]);
  return (
    <>{pieces.map(p => (
      <div key={p.id} className="confetti" style={{
        left: `${p.left}%`,
        background: p.bg,
        borderRadius: p.shape,
        transform: `rotate(${p.rot}deg)`,
        animationDelay: `${p.delay}s`,
        animationDuration: `${p.dur}s`,
      }} />
    ))}</>
  );
}

function Fireworks({ trigger = 0 }) {
  const [bursts, setBursts] = React.useState([]);
  React.useEffect(() => {
    if (!trigger) return;
    const colors = ['#fbbf24', '#ff4d8d', '#22d3ee', '#8b6dff', '#10e0a0'];
    const newBursts = [];
    for (let i = 0; i < 5; i++) {
      const cx = 20 + Math.random() * 60;
      const cy = 20 + Math.random() * 50;
      const color = colors[Math.floor(Math.random() * colors.length)];
      for (let j = 0; j < 14; j++) {
        const angle = (j / 14) * Math.PI * 2;
        newBursts.push({
          id: `${trigger}-${i}-${j}`,
          cx, cy,
          dx: Math.cos(angle) * 120,
          dy: Math.sin(angle) * 120,
          color,
          delay: i * 0.25,
        });
      }
    }
    setBursts(newBursts);
    const t = setTimeout(() => setBursts([]), 4000);
    return () => clearTimeout(t);
  }, [trigger]);
  return (
    <>{bursts.map(b => (
      <div key={b.id} className="firework" style={{
        left: `${b.cx}%`, top: `${b.cy}%`,
        background: b.color,
        boxShadow: `0 0 12px ${b.color}`,
        '--dx': `${b.dx}px`, '--dy': `${b.dy}px`,
        animationDelay: `${b.delay}s`,
      }} />
    ))}</>
  );
}

function QRBlock({ seed = 'PGF5' }) {
  // pseudo-random but stable grid for visual QR
  const size = 21;
  const cells = React.useMemo(() => {
    let s = 0;
    for (const ch of seed) s = (s * 31 + ch.charCodeAt(0)) >>> 0;
    const rand = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 0xffffffff; };
    const grid = Array.from({ length: size }, () => Array.from({ length: size }, () => rand() > 0.5));
    // finder patterns
    const stamp = (r, c) => {
      for (let i = 0; i < 7; i++) for (let j = 0; j < 7; j++) {
        const edge = i === 0 || i === 6 || j === 0 || j === 6;
        const inner = i >= 2 && i <= 4 && j >= 2 && j <= 4;
        grid[r + i][c + j] = edge || inner;
      }
      for (let i = -1; i <= 7; i++) for (let j = -1; j <= 7; j++) {
        const rr = r + i, cc = c + j;
        if (rr < 0 || cc < 0 || rr >= size || cc >= size) continue;
        if (i >= 0 && i < 7 && j >= 0 && j < 7) continue;
        if (i === -1 || i === 7 || j === -1 || j === 7) grid[rr][cc] = false;
      }
    };
    stamp(0, 0); stamp(0, 14); stamp(14, 0);
    return grid;
  }, [seed]);
  return (
    <svg viewBox={`0 0 ${size} ${size}`} shapeRendering="crispEdges">
      {cells.flatMap((row, r) =>
        row.map((on, c) => on ? <rect key={`${r}-${c}`} x={c} y={r} width="1" height="1" fill="#0a0824" /> : null)
      )}
    </svg>
  );
}

Object.assign(window, { AmbientDots, BgIcons, Confetti, Fireworks, QRBlock });
