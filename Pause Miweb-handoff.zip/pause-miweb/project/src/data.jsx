// Game data and helpers
const CATEGORIES = [
  { id: 'cassetete', label: 'Casse-tête', icon: '🧩', color: '#8b6dff' },
  { id: 'actus', label: 'Actualités', icon: '📰', color: '#22d3ee' },
  { id: 'fake', label: 'Fake News', icon: '🗯️', color: '#ff4d8d' },
  { id: 'celeb', label: 'Célébrités', icon: '⭐', color: '#fbbf24' },
  { id: 'geek', label: 'Geek', icon: '⟨/⟩', color: '#22d3ee' },
  { id: 'science', label: 'Science', icon: '⚛', color: '#10e0a0' },
  { id: 'histoire', label: 'Histoire', icon: '📖', color: '#f59e0b' },
  { id: 'trump', label: 'Trump', icon: '🎺', color: '#ff6d3d' },
  { id: 'anime', label: 'Anime & Disney', icon: '✧', color: '#ff4d8d' },
];

const QUOTES = [
  { text: "La culture, c'est comme la confiture : moins on en a, plus on l'étale.", author: 'Françoise Sagan' },
  { text: "Il vaut mieux mobiliser son intelligence sur des conneries que mobiliser sa connerie sur des choses intelligentes.", author: 'Jacques Rouxel' },
  { text: "L'important, c'est pas la chute, c'est l'atterrissage.", author: 'Matthieu Kassovitz' },
];

const QUESTIONS = [
  {
    cat: 'geek',
    text: 'Quel moteur de recherche a été lancé en 1998 par Larry Page et Sergey Brin ?',
    answers: ['Google', 'AltaVista', 'Lycos', 'Yahoo!'],
    correct: 0,
    fact: 'Google a été fondé en septembre 1998 dans un garage à Menlo Park.',
  },
  {
    cat: 'histoire',
    text: "En quelle année la Tour Eiffel a-t-elle été inaugurée ?",
    answers: ['1889', '1900', '1878', '1905'],
    correct: 0,
    fact: "Construite pour l'Exposition universelle de 1889, elle devait être démontée 20 ans plus tard.",
  },
  {
    cat: 'anime',
    text: 'Quel est le nom du chat robot bleu venu du futur ?',
    answers: ['Hello Kitty', 'Doraemon', 'Totoro', 'Pikachu'],
    correct: 1,
    fact: 'Doraemon vient de l\'an 2112 pour aider un jeune garçon maladroit.',
  },
  {
    cat: 'science',
    text: 'Combien y a-t-il d\'os dans le corps humain adulte ?',
    answers: ['186', '206', '256', '306'],
    correct: 1,
    fact: 'Un bébé naît avec environ 270 os qui fusionnent pour arriver à 206.',
  },
  {
    cat: 'celeb',
    text: 'Qui a réalisé le film "Pulp Fiction" ?',
    answers: ['Martin Scorsese', 'Quentin Tarantino', 'Coen Brothers', 'David Fincher'],
    correct: 1,
    fact: 'Sorti en 1994, il a remporté la Palme d\'Or à Cannes.',
  },
];

const PLAYER_POOL = [
  { name: 'Bertrand', color: '#7c5cff' },
  { name: 'Camille',  color: '#22d3ee' },
  { name: 'Léo',      color: '#10e0a0' },
  { name: 'Aïcha',    color: '#ff4d8d' },
  { name: 'Marc',     color: '#fbbf24' },
  { name: 'Zoé',      color: '#ff6d3d' },
  { name: 'Hugo',     color: '#a78bfa' },
  { name: 'Inès',     color: '#34d399' },
];

function initials(name) {
  return name.split(' ').map(p => p[0]).join('').slice(0,2).toUpperCase();
}

function catById(id) { return CATEGORIES.find(c => c.id === id) || CATEGORIES[0]; }

Object.assign(window, { CATEGORIES, QUOTES, QUESTIONS, PLAYER_POOL, initials, catById });
